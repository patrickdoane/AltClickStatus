### Fixed
- `/acs showrange` toggle now reliably adds/removes range suffix. Uses action-slot range with spell fallback.
